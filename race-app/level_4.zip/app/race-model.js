"use strict";
var RaceModel = (function () {
    function RaceModel() {
    }
    return RaceModel;
}());
exports.RaceModel = RaceModel;
//# sourceMappingURL=race-model.js.map